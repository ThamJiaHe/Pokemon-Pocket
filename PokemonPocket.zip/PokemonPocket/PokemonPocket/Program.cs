﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PokemonPocket
{
    class Program
    {
        static void Main(string[] args)
        {   
            //PokemonMaster list for checking pokemon evolution availability.    
            //new PokemonMaster(<Type of Pokemon>, <Required no. of the same type to evolve>, <Name of Pokemon it will evolve to>)
            List<PokemonMaster> pokemonMasters = new List<PokemonMaster>(){
            new PokemonMaster("Pikachu", 2, "Raichu"),
            new PokemonMaster("Eevee", 3, "Flareon"),
            new PokemonMaster("Charmander", 1, "Charmeleon")
            };

        //Use "Environment.Exit(0);" if you want to implement an exit of the console program
        //Start your assignment 1 requirements below.
         














        }
    }
}
